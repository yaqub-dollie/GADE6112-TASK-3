﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Map
    {
        private string display;
        private string[,] map = new string[20, 20];
        private MeleeUnit[] MU = new MeleeUnit[20];
        private int meleeUnitCount;
        private RangedUnit[] RU = new RangedUnit[20];
        private int rangedUnitCount;

       public string redraw()
        {
            display = "";
            {
            }
            return display;
        }

    }
}
